<?php
/**
 * Template tags used in Footer
 */
require get_template_directory() . '/inc/template-tags/footers/footer-v1.php';
require get_template_directory() . '/inc/template-tags/footers/footer-v2.php';
require get_template_directory() . '/inc/template-tags/footers/footer-v3.php';
require get_template_directory() . '/inc/template-tags/footers/footer-v4.php';
require get_template_directory() . '/inc/template-tags/footers/footer-handheld.php';
require get_template_directory() . '/inc/template-tags/footers/footer-landing.php';